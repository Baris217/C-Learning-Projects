# Kg ↔ Pound Converter (C Program)

A simple C program that converts between kilograms and pounds.  
This project was created for learning purposes and to practice basic C programming skills.

---

## How to Run

1. Compile the program:

gcc converter.c -o converter

2. Run the program:

./converter

---

## Features

- Convert Kilograms → Pounds  
- Convert Pounds → Kilograms  
- Simple and user-friendly terminal interface

---

## Example Usage

Enter a value and choose the conversion type:  
The program will display the converted result in the terminal.

---

## Note

This is one of my first projects uploaded to GitHub.  
Feel free to check it out, experiment with it, or suggest improvements!
