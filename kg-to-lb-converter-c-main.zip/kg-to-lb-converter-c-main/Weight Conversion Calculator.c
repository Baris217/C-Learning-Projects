#include <stdio.h>
#include <math.h>

int main() {

int choice ;
float pound ;
float kilogram ;

printf("Kilogram to Pound (1)\n") ;
printf("Pound to Kilogram (2)\n") ;

printf("Please select your choice:") ;
scanf("%d", &choice) ;

if(choice == 1) {
     printf("Enter your kilogram value:") ;
     scanf("%f", &kilogram) ;
     pound=kilogram * 2.2 ;
     printf("Here is your pound value:%.2f", pound) ;
}

else if(choice == 2) {
      printf("Enter your pound value:") ;
      scanf("%f", &pound) ;
      kilogram=pound / 2.2 ;
      printf("Here is your kilogram value:%.2f", kilogram) ;
}


   return 0;
}
