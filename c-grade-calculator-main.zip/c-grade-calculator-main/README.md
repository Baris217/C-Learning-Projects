# C Grade Calculator

This is a simple C program that takes a student's numeric score (0–100)
and prints the corresponding letter grade (AA–FF) using if-else statements.

## Concepts Used
- if / else if / else
- Integer comparison
- User input with scanf
- Basic C syntax

## Example
Input:
85

Output:
Your grade is BA


